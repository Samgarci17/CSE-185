
# THIS FILE IS GENERATED FROM SETUP.PY
version = '0.0.1'
__version__ = version